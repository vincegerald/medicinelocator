package com.example.myapplication.ui.home;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements OnMapReadyCallback {

    private HomeViewModel homeViewModel;
    private AutoCompleteTextView search;
    private TextView genericName, brandName, pharmacyName, location;
    private CardView cardView;
    private ImageView imageAd;
    private MapView mapView;
    private static final String MAP_VIEW_BUNDLE_KEY = "AIzaSyAmDm3beXfSIb2xpOUhwo52v8EogNWQBk4";
    GoogleMap mMap;

    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;
    Polyline currentPolyline;


    List<PharmacyModel> pharmacyList;
    PharmacyModel selected = null;

    private static final String URL = "https://medlocatorapp.000webhostapp.com/medlocator/api/search/available.php?search=";



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        mapView = root.findViewById(R.id.mapView);
        search = root.findViewById(R.id.searchText);
        cardView = root.findViewById(R.id.cardView);
        genericName = root.findViewById(R.id.genericName);
        brandName = root.findViewById(R.id.brandName);
        pharmacyName = root.findViewById(R.id.pharmacyName);
        imageAd = root.findViewById(R.id.imageAd);
        location = root.findViewById(R.id.location);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getActivity());

        imageAd.setImageResource(R.mipmap.ads2);
        imageAd.setScaleType(ImageView.ScaleType.FIT_XY);
        map(savedInstanceState);
        loadData();


        return root;
    }

    private void fetchLastLocation() {
       if(ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){

           ActivityCompat.requestPermissions(getActivity(), new String[]{
                   Manifest.permission.ACCESS_FINE_LOCATION
           }, REQUEST_CODE);

       }

        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(null != location){
                    currentLocation = location;
                    Toast.makeText(getActivity(), currentLocation.getLatitude() + " " + currentLocation.getLongitude(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void loadData(){
        pharmacyList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.GET, URL, response -> {
            try {
                JSONObject object = new JSONObject(response);
                JSONArray jsonArray = object.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    String pharmacyName = jsonObject.getString("pharmacyName");
                    String pharmacyId = jsonObject.getString("pharmacyId");
                    String location = jsonObject.getString("location");
                    String longitude = jsonObject.getString("longitude");
                    String latitude = jsonObject.getString("latitude");
                    String genericName = jsonObject.getString("genericName");
                    String brandName = jsonObject.getString("brandName");

                    PharmacyModel model = new PharmacyModel(pharmacyName, pharmacyId, location, longitude, latitude, genericName, brandName);
                    pharmacyList.add(model);
                }

                PharmacyAdapter adapter = new PharmacyAdapter(getContext(), pharmacyList);
                search.setAdapter(adapter);
                search.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        selected = (PharmacyModel) parent.getItemAtPosition(position);
                        onMapReady(mMap);
                    }
                });

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }, error -> {
            Toast.makeText(getContext(), "An error occured while connecting to the server", Toast.LENGTH_SHORT).show();
        });
        queue.add(request);
    }

    private void map(Bundle savedInstanceState){
        Bundle mapViewBundle = null;

        if(savedInstanceState != null){
            mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY);

        }
        mapView.onCreate(mapViewBundle);
        mapView.getMapAsync(this);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
        }

        mapView.onSaveInstanceState(mapViewBundle);
    }

    @Override
    public void onResume() {
        super.onResume();
        if(mMap != null){
            mMap.clear();
        }
        mapView.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();
        mapView.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    public void onMapReady(GoogleMap map) {

        LatLng ny = new LatLng(null != currentLocation ? currentLocation.getLatitude() : 0.00 , null != currentLocation ? currentLocation.getLongitude() : 0.00);
        LatLng current = new LatLng(null != currentLocation ? currentLocation.getLatitude() : 10.3157 , null != currentLocation ? currentLocation.getLongitude() : 123.8854);
        Marker marker = null;
        mMap = map;
        mMap.setMinZoomPreference(12);


        if(null != selected){

            mMap.clear();
            cardView.setVisibility(View.VISIBLE);
            genericName.setText(selected.getGenericName());
            brandName.setText(selected.getBrandName());
            pharmacyName.setText(selected.getPharmacyName());
            location.setText(selected.getLocation());
            ny = new LatLng(Double.parseDouble(selected.getLatitude()), Double.parseDouble(selected.getLongitude()));
            mMap.addMarker(new MarkerOptions().position(ny).title(selected.getPharmacyName()));
        }

        Toast.makeText(getActivity(), currentLocation + "", Toast.LENGTH_SHORT).show();
        MarkerOptions markerOptions = new MarkerOptions().position(current).title("You are here");
        mMap.animateCamera(CameraUpdateFactory.newLatLng(current));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(current, 5));
        mMap.addMarker(markerOptions);



        CameraPosition.Builder camBuilder = CameraPosition.builder();
        camBuilder.bearing(45);
        camBuilder.tilt(30);
        camBuilder.target(ny);
        camBuilder.zoom(15);

        CameraPosition cp = camBuilder.build();

        mMap.moveCamera(CameraUpdateFactory.newCameraPosition(cp));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case REQUEST_CODE:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    fetchLastLocation();
                }
                break;
        }
    }

    @Override
    public void onPause() {
        mapView.onPause();
        super.onPause();
    }

    @Override
    public void onDestroy() {
        mapView.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}