package com.example.myapplication.ui.home;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements OnMapReadyCallback {

    private HomeViewModel homeViewModel;
    private AutoCompleteTextView search;
    private TextView genericName, brandName, pharmacyName, location;
    private CardView cardView;
    private MapView mapView;
    private ImageButton gotoCurrentLoc;


    private static final String MAP_VIEW_BUNDLE_KEY = "AIzaSyAmDm3beXfSIb2xpOUhwo52v8EogNWQBk4";
    GoogleMap mMap;

    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;
    Polyline currentPolyline;

    MarkerOptions currentLoc, pharmacyLocation;

    List<PharmacyModel> pharmacyList;
    PharmacyModel selected = null;

    boolean locationBoolean = false;
    boolean pharmacyLocationBoolean = false;


    private static final String URL = "https://medlocatorapp.000webhostapp.com/medlocator/api/search/available.php?search=";



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        mapView = root.findViewById(R.id.mapView);
        search = root.findViewById(R.id.searchText);
        cardView = root.findViewById(R.id.cardView);
        genericName = root.findViewById(R.id.genericName);
        brandName = root.findViewById(R.id.brandName);
        pharmacyName = root.findViewById(R.id.pharmacyName);
        location = root.findViewById(R.id.location);
        gotoCurrentLoc = root.findViewById(R.id.currentLocation);



        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getActivity());
        fetchLastLocation();


        loadData();

        mapView.onCreate(savedInstanceState);
        mapView.onResume();
        mapView.getMapAsync(this);

        gotoCurrentLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pharmacyLocationBoolean = false;
                locationBoolean = true;
                onMapReady(mMap);
            }
        });


        return root;
    }


    private void fetchLastLocation() {
       if(ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){

           ActivityCompat.requestPermissions(getActivity(), new String[]{
                   Manifest.permission.ACCESS_FINE_LOCATION
           }, REQUEST_CODE);

       }

        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(null != location){
                    currentLocation = location;
                    //onMapReady(mMap);

                }
            }
        });

    }

    private void loadData(){
        pharmacyList = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.GET, URL, response -> {
            try {
                JSONObject object = new JSONObject(response);
                JSONArray jsonArray = object.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    String pharmacyName = jsonObject.getString("pharmacyName");
                    String pharmacyId = jsonObject.getString("pharmacyId");
                    String location = jsonObject.getString("location");
                    String longitude = jsonObject.getString("longitude");
                    String latitude = jsonObject.getString("latitude");
                    String genericName = jsonObject.getString("genericName");
                    String brandName = jsonObject.getString("brandName");
                    String date_updated = jsonObject.getString("date_updated");

                    PharmacyModel model = new PharmacyModel(pharmacyName, pharmacyId, location, longitude, latitude, genericName, brandName, date_updated);
                    pharmacyList.add(model);
                }

                PharmacyAdapter adapter = new PharmacyAdapter(getContext(), pharmacyList);
                search.setAdapter(adapter);
                search.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        selected = (PharmacyModel) parent.getItemAtPosition(position);
                        pharmacyLocationBoolean = true;
                        locationBoolean = false;
                        onMapReady(mMap);
                    }
                });

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }, error -> {
            Toast.makeText(getContext(), "An error occured while connecting to the server", Toast.LENGTH_SHORT).show();
        });
        queue.add(request);
    }

    private void map(Bundle savedInstanceState){
        Bundle mapViewBundle = null;

        if(savedInstanceState != null){
            mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY);

        }
        mapView.onCreate(mapViewBundle);
        mapView.getMapAsync(this);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
        }

        mapView.onSaveInstanceState(mapViewBundle);
    }

    @Override
    public void onResume() {
        super.onResume();
        if(mMap != null){
            mMap.clear();
        }
        mapView.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();
        mapView.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    public void onMapReady(GoogleMap map) {

        LatLng ny = new LatLng(null != currentLocation ? currentLocation.getLatitude() : 10.3157 , null != currentLocation ? currentLocation.getLongitude() : 123.8854);
        LatLng current = new LatLng(null != currentLocation ? currentLocation.getLatitude() : 0.00 , null != currentLocation ? currentLocation.getLongitude() : 0.00);
        Marker marker = null;
        mMap = map;

        if(null != selected){

            mMap.clear();

            cardView.setVisibility(View.VISIBLE);
            genericName.setText(selected.getGenericName());
            brandName.setText(selected.getBrandName());
            pharmacyName.setText(selected.getPharmacyName());
            location.setText(selected.getLocation());
            ny = new LatLng(Double.parseDouble(selected.getLatitude()), Double.parseDouble(selected.getLongitude()));
            pharmacyLocation = new MarkerOptions().position(ny).title(selected.getPharmacyName());
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    locationBoolean = false;
                    pharmacyLocationBoolean = true;
                    onMapReady(mMap);
                }
            });
            mMap.addMarker(pharmacyLocation);
            mMap.addPolyline(new PolylineOptions().add(ny).add(current).width(8f).color(Color.RED));
            mMap.addCircle(new CircleOptions().center(ny).radius(500.0).strokeWidth(3f).strokeColor(Color.RED).fillColor(Color.argb(70, 150, 50, 50)));
        }



        if(null != currentLocation){
            if(0.00 != currentLocation.getLatitude() && 0.00 != currentLocation.getLongitude()){
                currentLoc = new MarkerOptions().position(current).title("You are here").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));
                mMap.addCircle(new CircleOptions().center(current).radius(500.0).strokeWidth(3f).strokeColor(Color.RED).fillColor(Color.argb(70, 150, 50, 50)));
                mMap.addMarker(currentLoc);
            }
        }

        UiSettings uiSettings = map.getUiSettings();
        uiSettings.setIndoorLevelPickerEnabled(true);
        uiSettings.setMyLocationButtonEnabled(true);
        uiSettings.setMapToolbarEnabled(true);
        uiSettings.setCompassEnabled(true);
        uiSettings.setZoomControlsEnabled(true);

        CameraPosition.Builder camBuilder = CameraPosition.builder();
        camBuilder.bearing(45);
        camBuilder.tilt(30);
        camBuilder.target(ny);
        camBuilder.zoom(15);

        CameraPosition cp = camBuilder.build();

        mMap.setMinZoomPreference(12);

        if(locationBoolean){

            CameraPosition.Builder camBuilderCurrent = CameraPosition.builder();
            camBuilderCurrent.bearing(45);
            camBuilderCurrent.tilt(30);
            camBuilderCurrent.target(current);
            camBuilderCurrent.zoom(15);

            CameraPosition cpCurrent = camBuilderCurrent.build();

            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cpCurrent));

        }
        else {
            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cp));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case REQUEST_CODE:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    fetchLastLocation();
                }
                break;
        }
    }

    @Override
    public void onPause() {
        mapView.onPause();
        super.onPause();
    }

    @Override
    public void onDestroy() {
        mapView.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}