package com.example.myapplication.ui.promos;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private ArrayList<PromoItem> mItemsList;

    public static class ViewHolder extends RecyclerView.ViewHolder{

        public TextView mTextView1, mTextView2, mTextView3, mTextView4, indication;
        public CardView cardView;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mTextView1 = itemView.findViewById(R.id.title);
            mTextView2 = itemView.findViewById(R.id.description);
            mTextView3 = itemView.findViewById(R.id.desc);
            mTextView4 = itemView.findViewById(R.id.pharmacyName);
            indication = itemView.findViewById(R.id.indication);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }

    public Adapter(ArrayList<PromoItem> items){
        mItemsList = items;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        ViewHolder holder = new ViewHolder(v);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        PromoItem currentItem = mItemsList.get(position);

        holder.mTextView1.setText(currentItem.getTitle());
        holder.mTextView2.setText(currentItem.getDescription());
        holder.mTextView3.setVisibility(View.GONE);
        holder.indication.setVisibility(View.GONE);
        holder.mTextView4.setText(currentItem.getStartDate() + " - " + currentItem.getEndDate());

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return mItemsList.size();
    }

    public void filterList(ArrayList<PromoItem> filteredList){
        mItemsList = filteredList;
        notifyDataSetChanged();
    }
}
